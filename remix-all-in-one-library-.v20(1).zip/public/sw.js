const CACHE_NAME = 'aili-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/app_logo_icon_1787974156637.jpg'
];

// Install Event
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('Caching initial assets');
      return cache.addAll(ASSETS).catch(err => console.warn('Precache failed:', err));
    })
  );
  self.skipWaiting();
});

// Activate Event
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('Removing old cache:', key);
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch Event
self.addEventListener('fetch', (event) => {
  const req = event.request;
  
  // Skip API or non-GET requests
  if (req.method !== 'GET' || req.url.includes('/api/')) {
    return;
  }

  event.respondWith(
    caches.match(req).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }

      return fetch(req)
        .then((response) => {
          // Cache newly fetched static assets
          if (response && response.status === 200 && response.type === 'basic') {
            const responseClone = response.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(req, responseClone);
            });
          }
          return response;
        })
        .catch(() => {
          // If offline and request is HTML/navigation, serve root
          if (req.mode === 'navigate') {
            return caches.match('/');
          }
        });
    })
  );
});
