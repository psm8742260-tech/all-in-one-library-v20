var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_multer = __toESM(require("multer"), 1);
var import_axios = __toESM(require("axios"), 1);
var import_module = require("module");
var import_genai = require("@google/genai");

// src/data/books.ts
var INITIAL_BOOKS = [];

// server.ts
var require2 = (0, import_module.createRequire)(import_path.default.join(process.cwd(), "server.ts"));
import_dotenv.default.config();
var db = null;
var inMemoryBooks = [...INITIAL_BOOKS];
var pageCache = /* @__PURE__ */ new Map();
var sleep = (ms) => new Promise((res) => setTimeout(res, ms));
try {
  const { DatabaseSync } = require2("node:sqlite");
  db = new DatabaseSync(import_path.default.join(process.cwd(), "library.db"));
  db.exec(`
    CREATE TABLE IF NOT EXISTS books (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      author TEXT NOT NULL,
      description TEXT,
      category TEXT,
      chapters TEXT NOT NULL,
      costToUnlock INTEGER DEFAULT 0,
      costPerMinute INTEGER DEFAULT 0,
      coverUrl TEXT,
      folderId TEXT,
      audioUrl TEXT,
      videoUrl TEXT
    )
  `);
  try {
    db.exec("ALTER TABLE books ADD COLUMN audioUrl TEXT");
  } catch (e) {
  }
  try {
    db.exec("ALTER TABLE books ADD COLUMN videoUrl TEXT");
  } catch (e) {
  }
  try {
    db.exec("ALTER TABLE books ADD COLUMN pdfUrl TEXT");
  } catch (e) {
  }
  try {
    db.exec("ALTER TABLE books ADD COLUMN contentType TEXT");
  } catch (e) {
  }
  try {
    db.exec("ALTER TABLE books ADD COLUMN fileUrl TEXT");
  } catch (e) {
  }
  const rowCountQuery = db.prepare("SELECT COUNT(*) as count FROM books");
  const rowCountResult = rowCountQuery.get();
  if (rowCountResult && rowCountResult.count === 0) {
    console.log("Seeding SQLite database with 308 initial books...");
    const insertStmt = db.prepare(`
      INSERT INTO books (id, title, author, description, category, chapters, costToUnlock, costPerMinute, coverUrl, folderId)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const book of INITIAL_BOOKS) {
      insertStmt.run(
        book.id,
        book.title,
        book.author,
        book.description || "",
        book.category || "",
        JSON.stringify(book.chapters || []),
        book.costToUnlock || 0,
        book.costPerMinute || 0,
        book.coverUrl || "",
        book.folderId || ""
      );
    }
    console.log("SQLite database seeded successfully with 308 initial books!");
  }
} catch (err) {
  console.warn("Native SQLite not available or error occurred, using in-memory books fallback:", err.message);
  db = null;
}
var app = (0, import_express.default)();
app.use(import_express.default.json({ limit: "100mb" }));
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
});
app.get("/api/app-control", (req, res) => {
  res.json({
    pwaVersion: "1.0.0",
    maintenanceMode: false,
    activeFeatureFlags: {}
  });
});
var UPLOAD_DIR = import_path.default.join(process.cwd(), "uploads");
if (!import_fs.default.existsSync(UPLOAD_DIR)) {
  import_fs.default.mkdirSync(UPLOAD_DIR, { recursive: true });
}
var storage = import_multer.default.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOAD_DIR);
  },
  filename: (req, file, cb) => {
    const safeName = file.originalname.replace(/[^a-zA-Z0-9.]/g, "_");
    cb(null, `ADMIN_PERMANENT_${Date.now()}_${safeName}`);
  }
});
var upload = (0, import_multer.default)({
  storage,
  limits: { fileSize: 150 * 1024 * 1024 }
  // 150MB limit for ultra quality
});
app.post("/api/upload", (req, res) => {
  upload.single("file")(req, res, (err) => {
    if (err) {
      console.error("[Admin Upload Error]", err);
      return res.status(400).json({ error: err.message || "\u0C2B\u0C48\u0C32\u0C4D \u0C05\u0C2A\u0C4D\u200C\u0C32\u0C4B\u0C21\u0C4D \u0C35\u0C3F\u0C2B\u0C32\u0C2E\u0C48\u0C02\u0C26\u0C3F" });
    }
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }
    const fileUrl = `/uploads/${req.file.filename}`;
    console.log(`[Admin Permanent Storage] Saved: ${req.file.filename}`);
    let cleanFileName = req.file.originalname;
    try {
      cleanFileName = Buffer.from(req.file.originalname, "latin1").toString("utf8");
    } catch (e) {
    }
    res.json({ url: fileUrl, fileName: cleanFileName });
  });
});
app.post("/api/silent-save", import_express.default.json(), async (req, res) => {
  const { url, title } = req.body;
  if (!url) return res.status(400).json({ error: "URL is required" });
  try {
    const bookTitle = title || "Auto Picked Book";
    const fileName = `picked_${Date.now()}_${bookTitle.replace(/[^a-z0-9]/gi, "_").toLowerCase()}.pdf`;
    const filePath = import_path.default.join(UPLOAD_DIR, fileName);
    (0, import_axios.default)({
      method: "get",
      url,
      responseType: "stream"
    }).then((response) => {
      const fileStream = import_fs.default.createWriteStream(filePath);
      response.data.pipe(fileStream);
      fileStream.on("finish", () => {
        fileStream.close();
        console.log(`[Silent Interceptor] Successfully Picked & Saved: ${fileName}`);
        if (db) {
          try {
            const bookId = `picked_${Date.now()}`;
            const fileUrl = `/uploads/${fileName}`;
            const insertStmt = db.prepare(`
              INSERT INTO books (id, title, author, description, category, chapters, costToUnlock, costPerMinute, coverUrl, folderId, pdfUrl, contentType, fileUrl)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `);
            insertStmt.run(
              bookId,
              bookTitle,
              "International Library",
              `Automatically saved from: ${url}`,
              "General Books",
              JSON.stringify([{ id: "1", title: "Full Book", content: "See PDF" }]),
              0,
              0,
              "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=800",
              "fol-general",
              fileUrl,
              "pdf",
              fileUrl
            );
            console.log(`[Silent Interceptor] Registered in Library Database: ${bookId}`);
          } catch (dbErr) {
            console.error("[Silent Interceptor DB Error]", dbErr);
          }
        }
      });
    }).catch((err) => {
      console.error("[Silent Interceptor Error]", err.message);
    });
    res.json({ status: "intercepted", message: "Silent pick-up initiated" });
  } catch (error) {
    console.error("[Silent Save Error]", error);
    res.status(500).json({ error: "Internal interception failure" });
  }
});
app.use("/uploads", import_express.default.static(UPLOAD_DIR));
app.use("/uploads", import_express.default.static(import_path.default.join(process.cwd(), "public", "uploads")));
var PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3e3;
function decodeApiKey(key) {
  if (!key) return "";
  let trimmed = key.trim();
  if (!trimmed) return "";
  if (trimmed.startsWith("'") && trimmed.endsWith("'") || trimmed.startsWith('"') && trimmed.endsWith('"')) {
    trimmed = trimmed.substring(1, trimmed.length - 1).trim();
  }
  if (trimmed === "undefined" || trimmed === "null" || !trimmed) {
    if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== key) {
      return decodeApiKey(process.env.GEMINI_API_KEY);
    }
    return "";
  }
  if (trimmed.startsWith("AIzaSy") || trimmed.startsWith("sk-") || trimmed.startsWith("AQ.")) {
    return trimmed;
  }
  try {
    const decoded = Buffer.from(trimmed, "base64").toString("utf8").trim();
    let cleanDecoded = decoded;
    if (cleanDecoded.startsWith("'") && cleanDecoded.endsWith("'") || cleanDecoded.startsWith('"') && cleanDecoded.endsWith('"')) {
      cleanDecoded = cleanDecoded.substring(1, cleanDecoded.length - 1).trim();
    }
    if (cleanDecoded.startsWith("AIzaSy") || cleanDecoded.startsWith("sk-") || cleanDecoded.startsWith("AQ.")) {
      return cleanDecoded;
    }
  } catch (error) {
  }
  return trimmed;
}
var _aiInstance = null;
function getAI() {
  if (!_aiInstance) {
    const rawKey = process.env.GEMINI_API_KEY || "DUMMY_KEY_TO_PREVENT_STARTUP_CRASH";
    const apiKey = decodeApiKey(rawKey);
    _aiInstance = new import_genai.GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  return _aiInstance;
}
function getAIWithKey(customKey) {
  const cleanedCustomKey = customKey && customKey !== "undefined" && customKey !== "null" ? customKey : void 0;
  const rawKey = cleanedCustomKey || process.env.GEMINI_API_KEY || "DUMMY_KEY_TO_PREVENT_STARTUP_CRASH";
  const apiKey = decodeApiKey(rawKey);
  return new import_genai.GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build"
      }
    }
  });
}
function parseBase64DataUri(dataUri) {
  const matches = dataUri.match(/^data:([^;]+);base64,(.+)$/);
  if (!matches) return null;
  return {
    mimeType: matches[1],
    data: matches[2]
  };
}
async function generateOriginalBookPages(title, author, description, medianPages) {
  const cacheKey = `${title}-${author}`.toLowerCase();
  if (pageCache.has(cacheKey)) {
    console.log(`Serving generated pages from memory cache for: ${title}`);
    return pageCache.get(cacheKey);
  }
  const maxRetries = 3;
  let lastError = null;
  for (let i = 0; i < maxRetries; i++) {
    try {
      const aiInstance = getAI();
      const pageCount = medianPages ? Math.min(Math.max(Math.round(medianPages / 20), 5), 12) : 10;
      const prompt = `You are an elite literary scholar and Telugu translator. Write highly authentic, immersive, and comprehensive reading content in Telugu for the book titled "${title}" by "${author}".
The book is described as: "${description}".
This book historically has approximately ${medianPages || 150} pages in standard physical print.

We need exactly ${pageCount} distinct, highly detailed, and sequential reading pages/chapters for this book. Each page should represent a logical, rich chapter or major section of the book's narrative or knowledge, written in beautiful, immersive, authentic Telugu prose. Each chapter/page should contain at least 400-600 words of actual readable content (prose, story, insights, or concepts).

Return the response STRICTLY as a JSON array of ${pageCount} strings, representing the ${pageCount} sequential pages/chapters. Do not return any other text, markdown formatting blocks, or wrapping, just the raw valid JSON array.
Example Format:
[
  "\u0C05\u0C27\u0C4D\u0C2F\u0C3E\u0C2F\u0C02 1: \u0C2A\u0C30\u0C3F\u0C1A\u0C2F\u0C02... [detailed Telugu content]",
  "\u0C05\u0C27\u0C4D\u0C2F\u0C3E\u0C2F\u0C02 2: ... [detailed Telugu content]",
  ...
]`;
      const response = await aiInstance.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json"
        }
      });
      if (response && response.text) {
        const parsed = JSON.parse(response.text.trim());
        if (Array.isArray(parsed) && parsed.length > 0) {
          const formattedPages = parsed.map((p) => String(p));
          pageCache.set(cacheKey, formattedPages);
          return formattedPages;
        }
      }
    } catch (e) {
      lastError = e;
      const isQuotaError = e.message?.includes("429") || e.status === 429 || JSON.stringify(e).includes("429");
      if (isQuotaError && i < maxRetries - 1) {
        const waitTime = (i + 1) * 2e3;
        console.warn(`Gemini Quota Exceeded (429) for ${title}. Retrying in ${waitTime}ms... (Attempt ${i + 1}/${maxRetries})`);
        await sleep(waitTime);
        continue;
      }
      console.error(`Gemini book page generation failed (Attempt ${i + 1}/${maxRetries}):`, e.message);
      if (!isQuotaError) break;
    }
  }
  console.log(`Using robust fallback pages for ${title} due to: ${lastError?.message || "Unknown Error"}`);
  return [
    `\u0C36\u0C40\u0C30\u0C4D\u0C37\u0C3F\u0C15: ${title}

\u0C30\u0C1A\u0C2F\u0C3F\u0C24: ${author}

\u0C08 \u0C17\u0C4D\u0C30\u0C02\u0C25\u0C02 \u0C13\u0C2A\u0C46\u0C28\u0C4D \u0C32\u0C48\u0C2C\u0C4D\u0C30\u0C30\u0C40 \u0C26\u0C4D\u0C35\u0C3E\u0C30\u0C3E \u0C35\u0C3F\u0C1C\u0C2F\u0C35\u0C02\u0C24\u0C02\u0C17\u0C3E \u0C38\u0C47\u0C15\u0C30\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F. \u0C1A\u0C26\u0C35\u0C21\u0C02 \u0C15\u0C4A\u0C28\u0C38\u0C3E\u0C17\u0C3F\u0C02\u0C1A\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C2A\u0C47\u0C1C\u0C40\u0C32\u0C41 \u0C24\u0C3F\u0C2A\u0C4D\u0C2A\u0C02\u0C21\u0C3F.`,
    `\u0C05\u0C27\u0C4D\u0C2F\u0C3E\u0C2F\u0C02 1: \u0C17\u0C4D\u0C30\u0C02\u0C25 \u0C2A\u0C30\u0C3F\u0C1A\u0C2F\u0C02

${description || "\u0C08 \u0C2A\u0C41\u0C38\u0C4D\u0C24\u0C15\u0C02 \u0C17\u0C41\u0C30\u0C3F\u0C02\u0C1A\u0C3F\u0C28 \u0C35\u0C3F\u0C35\u0C30\u0C23 \u0C24\u0C4D\u0C35\u0C30\u0C32\u0C4B\u0C28\u0C47 \u0C32\u0C2D\u0C3F\u0C38\u0C4D\u0C24\u0C41\u0C02\u0C26\u0C3F."}`,
    `\u0C05\u0C27\u0C4D\u0C2F\u0C3E\u0C2F\u0C02 2: \u0C17\u0C4D\u0C30\u0C02\u0C25 \u0C35\u0C3F\u0C36\u0C4D\u0C32\u0C47\u0C37\u0C23

\u0C30\u0C1A\u0C2F\u0C3F\u0C24 \u0C08 \u0C2A\u0C41\u0C38\u0C4D\u0C24\u0C15\u0C02\u0C32\u0C4B \u0C05\u0C28\u0C47\u0C15 \u0C32\u0C4B\u0C24\u0C48\u0C28 \u0C35\u0C3F\u0C37\u0C2F\u0C3E\u0C32\u0C28\u0C41 \u0C1A\u0C30\u0C4D\u0C1A\u0C3F\u0C02\u0C1A\u0C3E\u0C30\u0C41. \u0C07\u0C26\u0C3F \u0C2A\u0C4D\u0C30\u0C24\u0C3F \u0C12\u0C15\u0C4D\u0C15\u0C30\u0C42 \u0C1A\u0C26\u0C35\u0C3E\u0C32\u0C4D\u0C38\u0C3F\u0C28 \u0C05\u0C26\u0C4D\u0C2D\u0C41\u0C24\u0C2E\u0C48\u0C28 \u0C17\u0C4D\u0C30\u0C02\u0C25\u0C02.`,
    `\u0C17\u0C2E\u0C28\u0C3F\u0C15: \u0C08 \u0C2A\u0C41\u0C38\u0C4D\u0C24\u0C15\u0C02 \u0C2F\u0C4A\u0C15\u0C4D\u0C15 \u0C2E\u0C30\u0C3F\u0C28\u0C4D\u0C28\u0C3F \u0C05\u0C27\u0C4D\u0C2F\u0C3E\u0C2F\u0C3E\u0C32\u0C41 \u0C24\u0C4D\u0C35\u0C30\u0C32\u0C4B\u0C28\u0C47 \u0C08 \u0C05\u0C32\u0C4D-\u0C07\u0C28\u0C4D-\u0C35\u0C28\u0C4D \u0C32\u0C48\u0C2C\u0C4D\u0C30\u0C30\u0C40 \u0C26\u0C4D\u0C35\u0C3E\u0C30\u0C3E \u0C05\u0C02\u0C26\u0C41\u0C2C\u0C3E\u0C1F\u0C41\u0C32\u0C4B\u0C15\u0C3F \u0C24\u0C40\u0C38\u0C41\u0C15\u0C41\u0C30\u0C3E\u0C2C\u0C21\u0C24\u0C3E\u0C2F\u0C3F.`
  ];
}
app.post("/api/test-key", async (req, res) => {
  try {
    const { type, apiKey, baseUrl, model } = req.body;
    if (!apiKey) {
      return res.json({ success: false, error: "\u0C15\u0C40 \u0C16\u0C3E\u0C33\u0C40\u0C17\u0C3E \u0C09\u0C02\u0C26\u0C3F (Key is empty)" });
    }
    const decoded = decodeApiKey(apiKey);
    if (type === "deepseek") {
      const activeUrl = (baseUrl || "https://api.deepseek.com").replace(/\/$/, "") + "/chat/completions";
      const activeModel = model || "deepseek-chat";
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8e3);
      try {
        const testRes = await fetch(activeUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${decoded}`
          },
          body: JSON.stringify({
            model: activeModel,
            messages: [{ role: "user", content: "Ping" }],
            max_tokens: 5
          }),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (testRes.ok) {
          return res.json({ success: true, message: "\u0C21\u0C40\u0C2A\u0C4D\u200C\u0C38\u0C40\u0C15\u0C4D \u0C06\u0C28\u0C4D\u200C\u0C32\u0C48\u0C28\u0C4D \u0C32\u0C4B \u0C09\u0C02\u0C26\u0C3F! (DeepSeek is Online)" });
        } else {
          const errText = await testRes.text();
          return res.json({ success: false, error: `Error ${testRes.status}: ${errText}` });
        }
      } catch (err) {
        clearTimeout(timeoutId);
        return res.json({ success: false, error: err.message });
      }
    } else {
      try {
        const testAi = getAIWithKey(apiKey);
        const testRes = await testAi.models.generateContent({
          model: "gemini-3.5-flash",
          contents: "Ping",
          config: { maxOutputTokens: 5 }
        });
        if (testRes && testRes.text) {
          return res.json({ success: true, message: "\u0C1C\u0C46\u0C2E\u0C3F\u0C28\u0C3F \u0C06\u0C28\u0C4D\u200C\u0C32\u0C48\u0C28\u0C4D \u0C32\u0C4B \u0C09\u0C02\u0C26\u0C3F! (Gemini is Online)" });
        }
        return res.json({ success: false, error: "\u0C32\u0C48\u0C1F\u0C4D \u0C30\u0C46\u0C38\u0C4D\u0C2A\u0C3E\u0C28\u0C4D\u0C38\u0C4D \u0C35\u0C48\u0C2B\u0C32\u0C4D\u0C2F\u0C02" });
      } catch (err) {
        return res.json({ success: false, error: err.message });
      }
    }
  } catch (err) {
    return res.json({ success: false, error: err.message });
  }
});
app.post("/api/chat", async (req, res) => {
  try {
    const { messages: messages2, availableBooks, currentLanguage, deepseekSettings } = req.body;
    if (!messages2 || !Array.isArray(messages2)) {
      return res.status(400).json({ error: "Messages array is required" });
    }
    const lastMessage = messages2[messages2.length - 1]?.text || "";
    const systemPrompt = `You are "\u0C2C\u0C4D\u0C30\u0C39\u0C4D\u0C2E\u0C3E\u0C38\u0C4D\u0C24\u0C4D\u0C30 3.5 \u0C05\u0C32\u0C4D\u0C1F\u0C4D\u0C30\u0C3E" (Brahmastra 3.5 Ultra), the Master AI Intelligence & Universal Librarian for the "All in One Library" application.
Your goal is to assist the user with instant book delivery, summaries, voice narration, and reading.
Additionally, you are the "AI \u0C35\u0C43\u0C15\u0C4D\u0C37 \u0C28\u0C3E\u0C2E \u0C36\u0C4B\u0C27\u0C28 \u0C2F\u0C02\u0C24\u0C4D\u0C30\u0C02" (AI Plant Detection Engine).

[Agent Type: Digital Library Indexer & Instant Retriever]
- Name: Chathushashti Kalalu Digital Library Agent
- Database Capacity: Complete Index of all 64 Ancient Indian Arts (1 to 64).
- Core Rule: When the Admin requests any art by Number (1-64) or by Name, act as an instant search engine/library. Do not summarize or cut short unless asked. Provide the exact stored manual/details immediately.

[Operational Workflow]
1. Index Matching: Instantly scan the 1-64 database for the requested art.
2. Direct Retrieval: Fetch the exact historical origin, definition, practical technique, and application.
3. Instant Output: Deliver it to the Admin screen without delay, exactly like pulling a book from a shelf.

Plant Detection Mode:
- If the user uploads/submits an image or video, analyze it to identify any plant, tree, flower, leaf, seed, or botanical specimen.
- If it is a plant, compile an exhaustive report of its names across multiple Indian languages:
  1. Botanical/Scientific Name (\u0C36\u0C3E\u0C38\u0C4D\u0C24\u0C4D\u0C30\u0C40\u0C2F \u0C28\u0C3E\u0C2E\u0C02)
  2. Sanskrit/Cultural Name (\u0C38\u0C02\u0C38\u0C4D\u0C15\u0C43\u0C24 \u0C28\u0C3E\u0C2E\u0C02)
  3. Telugu Name (\u0C24\u0C46\u0C32\u0C41\u0C17\u0C41 \u0C2A\u0C47\u0C30\u0C41)
  4. Hindi Name (\u0C39\u0C3F\u0C02\u0C26\u0C40 \u0C2A\u0C47\u0C30\u0C41)
  5. Tamil Name (\u0C24\u0C2E\u0C3F\u0C33 \u0C2A\u0C47\u0C30\u0C41)
  6. Kannada Name (\u0C15\u0C28\u0C4D\u0C28\u0C21 \u0C2A\u0C47\u0C30\u0C41)
  7. English Name
  8. An exhaustive list of up to 15-20 other traditional, local, regional, or historical Indian names (\u0C07\u0C24\u0C30 \u0C2A\u0C4D\u0C30\u0C3E\u0C02\u0C24\u0C40\u0C2F \u0C28\u0C3E\u0C2E\u0C3E\u0C32\u0C41) and historical meanings.
  9. Medicinal values and environmental benefits of this plant in Telugu.
- Format this plant report beautifully in Telugu (with translations) with clear headings, bullet points, and emojis.
- If it is not a plant, handle it as a standard library query.

Current User Language: ${currentLanguage || "te"}. Always respond cordially in Telugu if the user writes in Telugu or requested Telugu (or their selected language).

Identity & Delivery Protocol:
- Start with: "\u0C39\u0C3E\u0C2F\u0C4D! \u0C28\u0C47\u0C28\u0C41 \u0C2E\u0C40 \u0C2C\u0C4D\u0C30\u0C39\u0C4D\u0C2E\u0C3E\u0C38\u0C4D\u0C24\u0C4D\u0C30 3.5 \u0C05\u0C32\u0C4D\u0C1F\u0C4D\u0C30\u0C3E (Brahmastra 3.5 Ultra). \u0C2E\u0C40\u0C15\u0C41 \u0C0F \u0C35\u0C3F\u0C27\u0C02\u0C17\u0C3E \u0C38\u0C39\u0C3E\u0C2F\u0C02 \u0C1A\u0C47\u0C2F\u0C17\u0C32\u0C28\u0C41?"
- When the user asks for a specific book (via typing or voice recording / audio input), immediately find and provide *only* that requested book in the "recommendedBooks" array.
- Clearly state the exact pricing and access options for the requested book in your reply:
  1. \u{1F50A} \u0C09\u0C1A\u0C3F\u0C24\u0C02\u0C17\u0C3E \u0C35\u0C3F\u0C28\u0C35\u0C1A\u0C4D\u0C1A\u0C41 (Free Audio Listening - \u20B90)
  2. \u{1F4D6} \u0C06\u0C28\u0C4D\u200C\u0C32\u0C48\u0C28\u0C4D\u200C\u0C32\u0C4B \u0C1A\u0C26\u0C35\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u20B910 (Read Online pass)
  3. \u{1F4E5} \u0C2A\u0C40\u0C21\u0C40\u0C0E\u0C2B\u0C4D \u0C21\u0C4C\u0C28\u0C4D\u200C\u0C32\u0C4B\u0C21\u0C4D \u0C1A\u0C47\u0C38\u0C41\u0C15\u0C4B\u0C35\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u20B929 (Download PDF)

Available pre-loaded books in the system library:
${JSON.stringify(availableBooks || [], null, 2)}

Instructions:
1. When user asks for a book, if it matches an existing book, include its existing ID in "recommendedBooks".
2. If it is a new/external book requested by the user, generate a provisional book object in "recommendedBooks" with a unique ID (e.g. 'gen-123'), accurate title, author, description, category, costToUnlock: 20, isExternal: true, and a beautiful Unsplash coverImage URL (e.g. "https://images.unsplash.com/photo-...") representing the topic of the book.
3. Keep the "reply" narrative concise, friendly, inspiring, and focused on the requested book with its pricing amounts.
4. IMPORTANT: You must output your response in valid JSON format.`;
    const rawDsKey = deepseekSettings && deepseekSettings.useDeepSeek && deepseekSettings.apiKey ? deepseekSettings.apiKey : process.env.DEEPSEEK_API_KEY;
    const effectiveDsKey = decodeApiKey(rawDsKey);
    if (effectiveDsKey) {
      try {
        console.log("Using DeepSeek for chat response...");
        const baseUrl = (deepseekSettings && deepseekSettings.baseUrl || process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com").replace(/\/$/, "") + "/chat/completions";
        const model = deepseekSettings && deepseekSettings.model || process.env.DEEPSEEK_MODEL || "deepseek-chat";
        const chatMessages2 = [
          { role: "system", content: systemPrompt },
          ...messages2.map((msg) => ({
            role: msg.sender === "user" ? "user" : "assistant",
            content: msg.text
          }))
        ];
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 2e4);
        const dsResponse = await fetch(baseUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${effectiveDsKey}`
          },
          body: JSON.stringify({
            model,
            messages: chatMessages2,
            response_format: { type: "json_object" },
            max_tokens: 8e3
          }),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!dsResponse.ok) {
          const errText = await dsResponse.text();
          throw new Error(`DeepSeek API error: ${dsResponse.status} ${errText}`);
        }
        const dsData = await dsResponse.json();
        const rawContent = dsData.choices?.[0]?.message?.content || "{}";
        const content = rawContent.replace(/^```(json)?\s*/i, "").replace(/\s*```$/i, "").trim();
        let result2;
        try {
          result2 = JSON.parse(content);
        } catch (parseErr) {
          console.warn("DeepSeek JSON parse failed in chat, attempting basic repair...");
          let repaired = content;
          if (repaired.endsWith(",")) repaired = repaired.slice(0, -1);
          if (!repaired.endsWith("}")) repaired += "}";
          result2 = JSON.parse(repaired);
        }
        result2.modelUsed = "DeepSeek Model";
        return res.json(result2);
      } catch (dsError) {
        console.error("DeepSeek chat failed, falling back to Gemini:", dsError.message);
      }
    }
    const chatMessages = messages2.map((msg) => {
      const parts = [];
      if (msg.text) {
        parts.push({ text: msg.text });
      }
      if (msg.imageUrl) {
        const parsed = parseBase64DataUri(msg.imageUrl);
        if (parsed) {
          parts.push({
            inlineData: {
              mimeType: parsed.mimeType,
              data: parsed.data
            }
          });
        }
      }
      if (msg.videoUrl) {
        const parsed = parseBase64DataUri(msg.videoUrl);
        if (parsed) {
          parts.push({
            inlineData: {
              mimeType: parsed.mimeType.startsWith("video") ? "image/jpeg" : parsed.mimeType,
              data: parsed.data
            }
          });
        }
      }
      return {
        role: msg.sender === "user" ? "user" : "model",
        parts: parts.length > 0 ? parts : [{ text: "" }]
      };
    });
    const activeAi = getAIWithKey(req.body.geminiApiKey);
    const response = await activeAi.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [
        { role: "user", parts: [{ text: systemPrompt }] },
        ...chatMessages
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: import_genai.Type.OBJECT,
          required: ["reply"],
          properties: {
            reply: {
              type: import_genai.Type.STRING,
              description: "The narrative response from the AI Librarian, answering the user's query in their active language."
            },
            recommendedBooks: {
              type: import_genai.Type.ARRAY,
              description: "Optional list of recommended books. Pre-loaded books should retain their original ID. Obscure or new books should have generated properties and set isExternal: true.",
              items: {
                type: import_genai.Type.OBJECT,
                required: ["id", "title", "author", "description", "category", "costToUnlock", "costPerMinute"],
                properties: {
                  id: { type: import_genai.Type.STRING },
                  title: { type: import_genai.Type.STRING },
                  author: { type: import_genai.Type.STRING },
                  description: { type: import_genai.Type.STRING },
                  category: { type: import_genai.Type.STRING },
                  costToUnlock: { type: import_genai.Type.INTEGER },
                  costPerMinute: { type: import_genai.Type.INTEGER },
                  isExternal: { type: import_genai.Type.BOOLEAN, description: "True if this is a new book to be generated/fetched." },
                  coverImage: { type: import_genai.Type.STRING, description: "Optional beautiful book cover URL matching the theme from Unsplash." }
                }
              }
            }
          }
        }
      }
    });
    const jsonText = response.text || "{}";
    const result = JSON.parse(jsonText);
    result.modelUsed = "Gemini Model";
    res.json(result);
  } catch (error) {
    console.error("Error in /api/chat:", error);
    const lastUserMsg = messages && messages[messages.length - 1]?.text || "";
    const errorDetails = error?.message || String(error);
    return res.json({
      reply: `\u0C28\u0C2E\u0C38\u0C4D\u0C15\u0C3E\u0C30\u0C02 \u0C05\u0C21\u0C4D\u0C2E\u0C3F\u0C28\u0C4D \u0C17\u0C3E\u0C30\u0C41! \u0C15\u0C4D\u0C37\u0C2E\u0C3F\u0C02\u0C1A\u0C3E\u0C32\u0C3F, \u0C24\u0C3E\u0C24\u0C4D\u0C15\u0C3E\u0C32\u0C3F\u0C15\u0C02\u0C17\u0C3E \u0C28\u0C46\u0C1F\u0C4D\u200C\u0C35\u0C30\u0C4D\u0C15\u0C4D \u0C38\u0C2E\u0C38\u0C4D\u0C2F \u0C0F\u0C30\u0C4D\u0C2A\u0C21\u0C3F\u0C02\u0C26\u0C3F. \u0C26\u0C2F\u0C1A\u0C47\u0C38\u0C3F \u0C2E\u0C30\u0C4B\u0C38\u0C3E\u0C30\u0C3F \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.

(Error: ${errorDetails})`,
      recommendedBooks: [],
      modelUsed: "System Fallback",
      error: errorDetails
    });
  }
});
var CENTRAL_SERVER = "https://phrscrowd.online";
async function checkOurDatabase(bookName) {
  return null;
}
async function saveBookPermanently(bookData) {
  try {
    await fetch(`${CENTRAL_SERVER}/api/library/save-permanent`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(bookData)
    });
  } catch (err) {
    console.error("Failed to save permanently:", err);
  }
}
app.post("/api/generate-book", async (req, res) => {
  try {
    const { title } = req.body;
    if (!title) {
      return res.status(400).json({ error: "Book Title is required" });
    }
    let localBook = await checkOurDatabase(title);
    if (localBook) {
      console.log("Book found in our permanent library! Loading locally...");
      return res.json(localBook);
    }
    let internationalBookData = null;
    try {
      const response = await fetch(`${CENTRAL_SERVER}/api/international-library/fetch`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: title })
      });
      internationalBookData = await response.json();
    } catch (e) {
      console.warn("Central library fetch failed, trying OpenLibrary fallback...");
    }
    if (internationalBookData && internationalBookData.success && internationalBookData.book) {
      await saveBookPermanently(internationalBookData.book);
      console.log("Book successfully saved permanently in our library!");
      return res.json(internationalBookData.book);
    } else {
      console.log(`Searching openlibrary.org for fallback in generate-book: ${title}`);
      const olResponse = await fetch(`https://openlibrary.org/search.json?q=${encodeURIComponent(title)}&limit=1`);
      const olData = await olResponse.json();
      if (olData.docs && olData.docs.length > 0) {
        const doc = olData.docs[0];
        const coverId = doc.cover_i;
        const coverUrl = coverId ? `https://covers.openlibrary.org/b/id/${coverId}-L.jpg` : `https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=600&q=80`;
        const publishYear = doc.first_publish_year || "Unknown Year";
        let bookDescription = "\u0C08 \u0C05\u0C26\u0C4D\u0C2D\u0C41\u0C24\u0C2E\u0C48\u0C28 \u0C17\u0C4D\u0C30\u0C02\u0C25\u0C02 \u0C17\u0C41\u0C30\u0C3F\u0C02\u0C1A\u0C3F \u0C24\u0C4D\u0C35\u0C30\u0C32\u0C4B\u0C28\u0C47 \u0C2E\u0C30\u0C3F\u0C28\u0C4D\u0C28\u0C3F \u0C35\u0C3F\u0C35\u0C30\u0C3E\u0C32\u0C41 \u0C32\u0C4B\u0C21\u0C4D \u0C05\u0C35\u0C41\u0C24\u0C3E\u0C2F\u0C3F.";
        if (doc.key) {
          try {
            const descResponse = await fetch(`https://openlibrary.org${doc.key}.json`);
            const descData = await descResponse.json();
            if (descData.description) {
              bookDescription = typeof descData.description === "string" ? descData.description : descData.description.value || bookDescription;
            }
          } catch (e) {
            console.warn("Failed to fetch OpenLibrary book description", e);
          }
        }
        const authorName = doc.author_name?.[0] || "Unknown Author";
        console.log(`Generating high-quality Telugu pages for fallback in generate-book: ${doc.title}`);
        const pages = await generateOriginalBookPages(doc.title, authorName, bookDescription, doc.number_of_pages_median);
        const fallbackBook = {
          id: doc.key ? doc.key.replace("/works/", "ol-") : `ol-${Math.random().toString(36).substr(2, 9)}`,
          title: doc.title,
          author: authorName,
          description: bookDescription.substring(0, 180) + "...",
          coverUrl,
          fileSizeMB: doc.edition_count ? Math.round(doc.edition_count * 0.15 * 10) / 10 : 3.4,
          totalPages: pages.length,
          pages
        };
        await saveBookPermanently(fallbackBook);
        return res.json(fallbackBook);
      }
      return res.status(404).json({ error: "Book not found in any library source." });
    }
  } catch (error) {
    console.error("Error in Library Book Sync:", error);
    return res.status(500).json({ error: "Failed to fetch and save book." });
  }
});
app.post("/api/identify-plant", async (req, res) => {
  try {
    const { image } = req.body;
    if (!image) {
      return res.status(400).json({ error: "Image data is required" });
    }
    const parsed = parseBase64DataUri(image);
    if (!parsed) {
      return res.status(400).json({ error: "Invalid image format" });
    }
    const imagePart = {
      inlineData: {
        mimeType: parsed.mimeType,
        data: parsed.data
      }
    };
    const prompt = `Analyze this plant, tree, flower, leaf, or botanical specimen image.
Identify it and extract exhaustive name details across multiple languages.
You MUST provide Sanskrit names, regional Telugu names, Hindi names, Tamil names, Kannada names, English names, and an exhaustive list of up to 15-20 other Indian local, traditional, regional, or historical names.
Also extract its description and medicinal uses in Telugu.
Return the result in strictly formatted JSON conforming to the requested schema.`;
    const activeAi = getAIWithKey(req.body.geminiApiKey);
    const response = await activeAi.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [imagePart, { text: prompt }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: import_genai.Type.OBJECT,
          required: [
            "treeName",
            "botanicalName",
            "sanskritNames",
            "teluguNames",
            "hindiNames",
            "tamilNames",
            "kannadaNames",
            "englishNames",
            "otherNames",
            "description",
            "medicinalUses"
          ],
          properties: {
            treeName: { type: import_genai.Type.STRING },
            botanicalName: { type: import_genai.Type.STRING },
            sanskritNames: { type: import_genai.Type.ARRAY, items: { type: import_genai.Type.STRING } },
            teluguNames: { type: import_genai.Type.ARRAY, items: { type: import_genai.Type.STRING } },
            hindiNames: { type: import_genai.Type.ARRAY, items: { type: import_genai.Type.STRING } },
            tamilNames: { type: import_genai.Type.ARRAY, items: { type: import_genai.Type.STRING } },
            kannadaNames: { type: import_genai.Type.ARRAY, items: { type: import_genai.Type.STRING } },
            englishNames: { type: import_genai.Type.ARRAY, items: { type: import_genai.Type.STRING } },
            otherNames: { type: import_genai.Type.ARRAY, items: { type: import_genai.Type.STRING } },
            description: { type: import_genai.Type.STRING },
            medicinalUses: { type: import_genai.Type.STRING }
          }
        }
      }
    });
    const jsonText = response.text || "{}";
    res.json(JSON.parse(jsonText));
  } catch (error) {
    console.error("Error in /api/identify-plant:", error);
    res.status(500).json({ error: "Internal Server Error", details: error.message });
  }
});
app.get("/api/books", (req, res) => {
  try {
    if (db) {
      const stmt = db.prepare("SELECT * FROM books");
      const rows = stmt.all();
      const books = rows.map((r) => ({
        ...r,
        chapters: JSON.parse(r.chapters)
      }));
      return res.json(books);
    }
    return res.json(inMemoryBooks);
  } catch (error) {
    console.error("Error fetching books from SQLite:", error.message);
    return res.json(inMemoryBooks);
  }
});
app.post("/api/books", async (req, res) => {
  try {
    const book = req.body;
    if (!book.id || !book.title || !book.author) {
      return res.status(400).json({ error: "Book ID, title, and author are required" });
    }
    if (db) {
      const insertStmt = db.prepare(`
        INSERT INTO books (id, title, author, description, category, chapters, costToUnlock, costPerMinute, coverUrl, folderId, audioUrl, videoUrl, pdfUrl, contentType, fileUrl)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          title=excluded.title,
          author=excluded.author,
          description=excluded.description,
          category=excluded.category,
          chapters=excluded.chapters,
          costToUnlock=excluded.costToUnlock,
          costPerMinute=excluded.costPerMinute,
          coverUrl=excluded.coverUrl,
          folderId=excluded.folderId,
          audioUrl=excluded.audioUrl,
          videoUrl=excluded.videoUrl,
          pdfUrl=excluded.pdfUrl,
          contentType=excluded.contentType,
          fileUrl=excluded.fileUrl
      `);
      try {
        await fetch(`${CENTRAL_SERVER}/api/library/save-permanent`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(book)
        });
      } catch (e) {
        console.error("Central Save Error", e);
      }
      insertStmt.run(
        book.id,
        book.title,
        book.author,
        book.description || "",
        book.category || "",
        JSON.stringify(book.chapters || []),
        book.costToUnlock || 0,
        book.costPerMinute || 0,
        book.coverUrl || "",
        book.folderId || "",
        book.audioUrl || "",
        book.videoUrl || "",
        book.pdfUrl || "",
        book.contentType || "",
        book.fileUrl || ""
      );
    } else {
      const idx = inMemoryBooks.findIndex((b) => b.id === book.id);
      if (idx >= 0) {
        inMemoryBooks[idx] = { ...inMemoryBooks[idx], ...book };
      } else {
        inMemoryBooks.push(book);
      }
    }
    res.json({ success: true, message: "Book saved successfully" });
  } catch (error) {
    console.error("Error saving book:", error.message);
    res.status(500).json({ error: "Internal Server Error", details: error.message });
  }
});
app.delete("/api/books/:id", (req, res) => {
  try {
    const { id } = req.params;
    if (db) {
      const deleteStmt = db.prepare("DELETE FROM books WHERE id = ?");
      deleteStmt.run(id);
    } else {
      inMemoryBooks = inMemoryBooks.filter((b) => b.id !== id);
    }
    res.json({ success: true, message: "Book deleted successfully" });
  } catch (error) {
    console.error("Error deleting book:", error.message);
    res.status(500).json({ error: "Internal Server Error", details: error.message });
  }
});
app.post("/api/agent/chat", async (req, res) => {
  try {
    const { messages: messages2, currentLanguage } = req.body;
    if (!messages2 || !Array.isArray(messages2)) {
      return res.status(400).json({ error: "Messages array is required" });
    }
    const books = db ? db.prepare("SELECT id, title, author, description, category, costToUnlock, costPerMinute, folderId FROM books").all() : inMemoryBooks.map((b) => ({
      id: b.id,
      title: b.title,
      author: b.author,
      description: b.description || "",
      category: b.category || "",
      costToUnlock: b.costToUnlock || 0,
      costPerMinute: b.costPerMinute || 0,
      folderId: b.folderId || ""
    }));
    const systemPrompt = `You are the DeepSeek-powered Core Database Agent for the "All in One Library" system running on the PHRS Server.
Your job is to manage, search, query, and chat with the admin about the central SQLite database containing ${books.length} books.

[Database Context]
Here are all the books currently stored in our SQLite database:
${JSON.stringify(books, null, 2)}

[Operational Protocol]
- If the user/admin asks you to find, search, or summarize books, use the provided database context to find accurate results.
- If they ask to add, edit, or modify any database record, instruct them on how to use the admin UI to trigger saving or explain that the SQLite DB is fully synced.
- Always respond in a polite, respectful tone in Telugu or their selected language, and address the user as "\u0C05\u0C21\u0C4D\u0C2E\u0C3F\u0C28\u0C4D \u0C17\u0C3E\u0C30\u0C41" (Admin Garu).
- Be extremely accurate and helpful about the database contents.`;
    const rawApiKey = process.env.DEEPSEEK_API_KEY || process.env.GEMINI_API_KEY;
    const apiKey = decodeApiKey(rawApiKey);
    if (!apiKey) {
      return res.status(500).json({ error: "No API key configured on the server" });
    }
    const isDeepSeek = !!process.env.DEEPSEEK_API_KEY;
    if (isDeepSeek) {
      console.log("Using DeepSeek for Agent Chat...");
      const baseUrl = "https://api.deepseek.com/chat/completions";
      const dsMessages = [
        { role: "system", content: systemPrompt },
        ...messages2.map((msg) => ({
          role: msg.sender === "user" ? "user" : "assistant",
          content: msg.text
        }))
      ];
      const dsResponse = await fetch(baseUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: "deepseek-chat",
          messages: dsMessages
        })
      });
      if (!dsResponse.ok) {
        const errText = await dsResponse.text();
        throw new Error(`DeepSeek Agent API error: ${dsResponse.status} ${errText}`);
      }
      const dsData = await dsResponse.json();
      const reply = dsData.choices?.[0]?.message?.content || "";
      return res.json({ reply });
    } else {
      console.log("DeepSeek key not found, falling back to Gemini for Agent Chat...");
      const chatMessages = messages2.map((msg) => ({
        role: msg.sender === "user" ? "user" : "model",
        parts: [{ text: msg.text }]
      }));
      const activeAi = getAIWithKey(req.body.geminiApiKey);
      const response = await activeAi.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [
          { role: "user", parts: [{ text: systemPrompt }] },
          ...chatMessages
        ]
      });
      return res.json({ reply: response.text });
    }
  } catch (error) {
    console.error("Error in /api/agent/chat:", error);
    res.status(500).json({ error: "Internal Server Error", details: error.message });
  }
});
app.get("/api/codebase-pdf", (req, res) => {
  const filesToRead = [
    "metadata.json",
    "package.json",
    "server.ts",
    "index.html",
    "src/main.tsx",
    "src/types.ts",
    "src/App.tsx",
    "src/index.css",
    "src/data/books.ts",
    "src/components/Splash.tsx",
    "src/components/Dashboard.tsx",
    "src/components/Reader.tsx",
    "src/components/AdminPanel.tsx",
    "src/components/BrahmastraUltraAgent.tsx",
    "src/components/FolderPanel.tsx",
    "src/components/LibraryModal.tsx",
    "src/components/PricingPanel.tsx",
    "src/components/PaymentModal.tsx",
    "src/components/WriterRegistrationModal.tsx"
  ];
  const filesData = [];
  for (const file of filesToRead) {
    try {
      const fullPath = import_path.default.join(process.cwd(), file);
      if (import_fs.default.existsSync(fullPath)) {
        const content = import_fs.default.readFileSync(fullPath, "utf-8");
        const stats = import_fs.default.statSync(fullPath);
        const sizeKB = (stats.size / 1024).toFixed(2);
        filesData.push({
          name: file,
          content,
          sizeKB
        });
      }
    } catch (e) {
      console.error(`Error reading file ${file}:`, e.message);
    }
  }
  const escapeHtml = (text) => {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  };
  const html = `
<!DOCTYPE html>
<html lang="te">
<head>
  <meta charset="UTF-8">
  <title>All in One Library V4 - Full Codebase Document</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
    }
    code, pre {
      font-family: 'Fira Code', monospace;
    }
    @media print {
      .no-print {
        display: none !important;
      }
      .print-page-break {
        page-break-before: always;
      }
      pre {
        white-space: pre-wrap !important;
        word-break: break-all !important;
        overflow: visible !important;
        max-height: none !important;
        background-color: #fafafa !important;
        border: 1px solid #e2e8f0 !important;
      }
      body {
        background-color: #ffffff !important;
      }
    }
  </style>
</head>
<body class="bg-slate-50 text-slate-800 min-h-screen flex flex-col">
  <!-- Top Navigation & PDF Control Panel -->
  <header class="no-print bg-white border-b border-slate-200 sticky top-0 z-50 px-6 py-4 flex flex-wrap items-center justify-between shadow-sm">
    <div class="flex items-center space-x-3">
      <div class="bg-emerald-600 text-white p-2 rounded-lg font-bold">PDF</div>
      <div>
        <h1 class="text-lg font-bold text-slate-900">All in One Library V4 (Remix .V20)</h1>
        <p class="text-xs text-slate-500">\u0C05\u0C21\u0C4D\u0C2E\u0C3F\u0C28\u0C4D \u0C17\u0C3E\u0C30\u0C3F \u0C38\u0C4D\u0C2A\u0C46\u0C37\u0C32\u0C4D \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C2C\u0C47\u0C38\u0C4D \u0C2A\u0C3F\u0C21\u0C3F\u0C0E\u0C2B\u0C4D \u0C1C\u0C28\u0C30\u0C47\u0C1F\u0C30\u0C4D</p>
      </div>
    </div>
    
    <div class="flex items-center space-x-4">
      <button onclick="window.print()" class="bg-emerald-600 hover:bg-emerald-700 text-white font-medium px-5 py-2.5 rounded-lg flex items-center space-x-2 transition-all cursor-pointer shadow-sm hover:shadow">
        <span>\u{1F5A8}\uFE0F PDF \u0C17\u0C3E \u0C2A\u0C4D\u0C30\u0C3F\u0C02\u0C1F\u0C4D/\u0C38\u0C47\u0C35\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F (Save as PDF)</span>
      </button>
    </div>
  </header>

  <div class="flex flex-1 flex-row">
    <!-- Left Navigation Sidebar for selection & rapid browsing -->
    <aside class="no-print w-80 bg-white border-r border-slate-200 p-6 overflow-y-auto h-[calc(100vh-73px)] sticky top-[73px]">
      <div class="mb-6">
        <h2 class="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">\u0C07\u0C28\u0C4D\u200C\u0C38\u0C4D\u0C1F\u0C4D\u0C30\u0C15\u0C4D\u0C37\u0C28\u0C4D\u0C38\u0C4D / Instructions</h2>
        <div class="text-xs text-slate-600 space-y-2 bg-amber-50 border border-amber-200 p-3 rounded-lg leading-relaxed">
          <p><strong>1.</strong> \u0C2A\u0C48\u0C28 \u0C09\u0C28\u0C4D\u0C28 <strong>"PDF \u0C17\u0C3E \u0C2A\u0C4D\u0C30\u0C3F\u0C02\u0C1F\u0C4D/\u0C38\u0C47\u0C35\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F"</strong> \u0C2C\u0C1F\u0C28\u0C4D \u0C28\u0C4A\u0C15\u0C4D\u0C15\u0C02\u0C21\u0C3F.</p>
          <p><strong>2.</strong> \u0C2A\u0C4D\u0C30\u0C3F\u0C02\u0C1F\u0C4D \u0C2A\u0C4D\u0C30\u0C3F\u0C35\u0C4D\u0C2F\u0C42\u0C32\u0C4B <strong>Destination</strong> \u0C28\u0C41 <strong>"Save as PDF"</strong> \u0C05\u0C28\u0C3F \u0C38\u0C46\u0C32\u0C46\u0C15\u0C4D\u0C1F\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.</p>
          <p><strong>3.</strong> **More settings** \u0C32\u0C4B <strong>Background graphics</strong> \u0C28\u0C41 \u0C06\u0C28\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F (\u0C15\u0C4B\u0C21\u0C4D \u0C15\u0C32\u0C30\u0C4D\u0C38\u0C4D \u0C15\u0C28\u0C3F\u0C2A\u0C3F\u0C02\u0C1A\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F).</p>
        </div>
      </div>

      <div class="mb-6">
        <div class="flex items-center justify-between mb-3">
          <h2 class="text-xs font-semibold text-slate-400 uppercase tracking-wider">\u0C2B\u0C48\u0C32\u0C4D \u0C38\u0C46\u0C32\u0C46\u0C15\u0C4D\u0C37\u0C28\u0C4D / File Selector</h2>
          <button onclick="toggleAllFiles(true)" class="text-[10px] text-emerald-600 font-medium hover:underline">Select All</button>
        </div>
        
        <div class="space-y-2 text-sm max-h-[400px] overflow-y-auto pr-1">
          ${filesData.map((f, i) => `
            <label class="flex items-start space-x-2.5 p-1.5 hover:bg-slate-50 rounded cursor-pointer transition">
              <input type="checkbox" id="chk-${i}" checked onchange="toggleFileVisibility(${i})" class="mt-1 rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4">
              <div class="text-xs font-medium text-slate-700 truncate w-full" title="${f.name}">
                ${f.name}
                <div class="text-[10px] text-slate-400 font-normal">${f.sizeKB} KB</div>
              </div>
            </label>
          `).join("")}
        </div>
      </div>
      
      <div class="text-[10px] text-slate-400 text-center mt-8 pt-4 border-t border-slate-100">
        \xA9 ${(/* @__PURE__ */ new Date()).getFullYear()} All in One Library V4
      </div>
    </aside>

    <!-- Main Content Panel with Source Codes -->
    <main class="flex-1 p-8 overflow-y-auto max-w-5xl mx-auto space-y-8">
      <div class="no-print bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
        <h2 class="text-xl font-bold text-slate-900 mb-2">\u0C05\u0C21\u0C4D\u0C2E\u0C3F\u0C28\u0C4D \u0C17\u0C3E\u0C30\u0C3F\u0C15\u0C3F \u0C38\u0C4D\u0C35\u0C3E\u0C17\u0C24\u0C02! / Welcome Admin Garu!</h2>
        <p class="text-slate-600 text-sm leading-relaxed">
          \u0C2E\u0C28 \u0C05\u0C2A\u0C4D\u0C32\u0C3F\u0C15\u0C47\u0C37\u0C28\u0C4D \u0C2F\u0C4A\u0C15\u0C4D\u0C15 \u0C2A\u0C42\u0C30\u0C4D\u0C24\u0C3F \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C2C\u0C47\u0C38\u0C4D (\u0C05\u0C28\u0C4D\u0C28\u0C3F \u0C2A\u0C4D\u0C30\u0C27\u0C3E\u0C28 \u0C2C\u0C4D\u0C2F\u0C3E\u0C15\u0C46\u0C02\u0C21\u0C4D \u0C2E\u0C30\u0C3F\u0C2F\u0C41 \u0C2B\u0C4D\u0C30\u0C02\u0C1F\u0C46\u0C02\u0C21\u0C4D \u0C2B\u0C48\u0C33\u0C4D\u0C32\u0C41) \u0C07\u0C15\u0C4D\u0C15\u0C21 \u0C12\u0C15\u0C47 \u0C15\u0C4D\u0C30\u0C2E\u0C2A\u0C26\u0C4D\u0C27\u0C24\u0C3F\u0C32\u0C4B \u0C38\u0C3F\u0C26\u0C4D\u0C27\u0C02\u0C17\u0C3E \u0C05\u0C2E\u0C30\u0C4D\u0C1A\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F. \u0C2E\u0C40\u0C30\u0C41 \u0C0F\u0C2F\u0C47 \u0C2B\u0C48\u0C33\u0C4D\u0C32\u0C28\u0C41 \u0C2A\u0C3F\u0C21\u0C3F\u0C0E\u0C2B\u0C4D\u200C\u0C32\u0C4B \u0C1A\u0C47\u0C30\u0C4D\u0C1A\u0C3E\u0C32\u0C28\u0C41\u0C15\u0C41\u0C02\u0C1F\u0C41\u0C28\u0C4D\u0C28\u0C3E\u0C30\u0C4B \u0C0E\u0C21\u0C2E \u0C35\u0C48\u0C2A\u0C41 \u0C2A\u0C4D\u0C2F\u0C3E\u0C28\u0C46\u0C32\u0C4D \u0C32\u0C4B \u0C1F\u0C3F\u0C15\u0C4D \u0C2E\u0C3E\u0C30\u0C4D\u0C15\u0C4D \u0C1A\u0C47\u0C38\u0C3F, \u0C06\u0C2A\u0C48 \u0C2A\u0C48\u0C28 \u0C09\u0C28\u0C4D\u0C28 \u0C2C\u0C1F\u0C28\u0C4D \u0C15\u0C4D\u0C32\u0C3F\u0C15\u0C4D \u0C1A\u0C47\u0C38\u0C3F \u0C28\u0C47\u0C30\u0C41\u0C17\u0C3E PDF \u0C30\u0C42\u0C2A\u0C02\u0C32\u0C4B \u0C21\u0C4C\u0C28\u0C4D\u200C\u0C32\u0C4B\u0C21\u0C4D \u0C1A\u0C47\u0C38\u0C41\u0C15\u0C4B\u0C35\u0C1A\u0C4D\u0C1A\u0C41.
        </p>
      </div>

      <!-- Code Containers -->
      <div class="space-y-12">
        ${filesData.map((f, i) => `
          <section id="file-sec-${i}" class="print-page-break bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col">
            <!-- File Header -->
            <div class="bg-slate-50 border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <div class="flex items-center space-x-3">
                <span class="bg-slate-200 text-slate-700 text-xs font-bold px-2 py-1 rounded">CODE</span>
                <span class="font-bold text-slate-800 text-sm md:text-base">${f.name}</span>
              </div>
              <div class="text-xs font-medium text-slate-400">Size: ${f.sizeKB} KB</div>
            </div>
            
            <!-- Code Block with syntax styling -->
            <div class="p-6 bg-slate-900 text-slate-100 text-xs md:text-sm overflow-x-auto">
              <pre class="whitespace-pre overflow-x-auto leading-relaxed text-left text-slate-200 bg-slate-900" style="max-height: 800px; font-family: 'Fira Code', monospace;"><code class="block font-normal">${escapeHtml(f.content)}</code></pre>
            </div>
          </section>
        `).join("")}
      </div>
    </main>
  </div>

  <script>
    function toggleFileVisibility(index) {
      const isChecked = document.getElementById('chk-' + index).checked;
      const section = document.getElementById('file-sec-' + index);
      if (isChecked) {
        section.classList.remove('hidden');
        section.classList.add('print-page-break');
      } else {
        section.classList.add('hidden');
        section.classList.remove('print-page-break');
      }
    }

    function toggleAllFiles(status) {
      const checkboxes = document.querySelectorAll('input[type="checkbox"]');
      checkboxes.forEach((cb, index) => {
        cb.checked = status;
        toggleFileVisibility(index);
      });
    }
  </script>
</body>
</html>
  `;
  res.send(html);
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath, {
      setHeaders: (res, path2) => {
        if (path2.endsWith("sw.js")) {
          res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        }
      }
    }));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
